make html
cp -r build/html/* ../../geoplotlib-ghpages
